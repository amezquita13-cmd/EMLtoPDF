param(
  [string]$scriptPath,
  [string]$inFolder,
  [string]$outFolder,
  [string]$exitPath
)

$ErrorActionPreference = 'Stop'

# Fallbacks if the Parameters grid doesn’t bind
if ([string]::IsNullOrWhiteSpace($scriptPath) -and $args.Count -ge 1) { $scriptPath = $args[0] }
if ([string]::IsNullOrWhiteSpace($inFolder)   -and $args.Count -ge 2) { $inFolder   = $args[1] }
if ([string]::IsNullOrWhiteSpace($outFolder)  -and $args.Count -ge 3) { $outFolder  = $args[2] }
if ([string]::IsNullOrWhiteSpace($exitPath)   -and $args.Count -ge 4) { $exitPath   = $args[3] }

if ([string]::IsNullOrWhiteSpace($exitPath) -and -not [string]::IsNullOrWhiteSpace($scriptPath)) {
  $exitPath = Join-Path (Split-Path -Parent $scriptPath) 'eml2pdf.exit'
}

$exe  = "$env:SystemRoot\System32\cscript.exe"

# Run cscript and CAPTURE stdout+stderr into an array
$out = & $exe //nologo "$scriptPath" "$inFolder" "$outFolder" 2>&1

# Persist the exit code for UiPath to read
[System.IO.File]::WriteAllText($exitPath, [string]$LASTEXITCODE, [System.Text.Encoding]::ASCII)

# Emit the captured lines back to UiPath (Invoke PowerShell Output)
$out
